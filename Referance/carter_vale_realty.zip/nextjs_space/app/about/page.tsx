'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Building2, Target, Award, Heart, TrendingUp, Users } from 'lucide-react';
import { BRAND } from '@/lib/constants';
import Link from 'next/link';

export default function AboutPage() {
  const { ref: valuesRef, inView: valuesInView } = useInView({ triggerOnce: true, threshold: 0.1 });

  const values = [
    {
      icon: Target,
      title: 'Client-Focused',
      description: 'Your goals are our priority. We listen, understand, and deliver solutions tailored to your unique needs.',
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'We maintain the highest standards in every transaction, ensuring exceptional service and results.',
    },
    {
      icon: Heart,
      title: 'Integrity',
      description: 'Transparency and honesty guide every interaction. We build lasting relationships based on trust.',
    },
    {
      icon: TrendingUp,
      title: 'Innovation',
      description: 'We leverage cutting-edge technology and market insights to give our clients a competitive advantage.',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-white py-16">
        <div className="mx-auto max-w-content px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">
            About <span className="text-accent">{BRAND?.name ?? ''}</span>
          </h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            {BRAND?.tagline ?? ''}
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-content px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-white rounded-lg shadow-lg p-8 md:p-12 mb-16">
          <div className="flex items-center gap-3 mb-6">
            <Building2 className="w-10 h-10 text-accent" />
            <h2 className="text-3xl font-serif font-bold text-primary">Our Story</h2>
          </div>
          <div className="space-y-4 text-gray-700 leading-relaxed">
            <p>
              Founded in {BRAND?.founded ?? ''}, {BRAND?.name ?? ''} was established with a clear vision: to revolutionize 
              the real estate experience in Texas by combining expert market knowledge with personalized service.
            </p>
            <p>
              Over the past {new Date()?.getFullYear?.() - (BRAND?.founded ?? 2012)} years, we have grown from a small Austin-based 
              firm to a premier real estate group serving Austin, Dallas, and Houston. Our success is built on the foundation 
              of understanding that every client&apos;s needs are unique, whether they&apos;re searching for their dream home, 
              expanding their business footprint, or building an investment portfolio.
            </p>
            <p>
              Today, we specialize in commercial real estate, office leasing, residential properties, and investment opportunities. 
              Our team of experienced agents brings deep local market knowledge and a commitment to excellence that has helped 
              hundreds of clients achieve their real estate goals.
            </p>
          </div>
        </div>

        <div className="mb-16" ref={valuesRef}>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-primary text-center mb-12">
            Our <span className="text-accent">Values</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values?.map?.((value, index) => {
              const Icon = value?.icon;
              return (
                <motion.div
                  key={value?.title ?? index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={valuesInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white rounded-lg shadow-md p-6 text-center hover:shadow-xl transition-shadow duration-300"
                >
                  {Icon && <Icon className="w-12 h-12 text-accent mx-auto mb-4" />}
                  <h3 className="text-xl font-serif font-bold text-primary mb-3">{value?.title ?? ''}</h3>
                  <p className="text-sm text-gray-600 leading-relaxed">{value?.description ?? ''}</p>
                </motion.div>
              );
            }) ?? []}
          </div>
        </div>

        <div className="bg-secondary-bg rounded-lg p-8 md:p-12 text-center">
          <Users className="w-16 h-16 text-accent mx-auto mb-6" />
          <h2 className="text-3xl font-serif font-bold text-primary mb-4">Ready to Work With Us?</h2>
          <p className="text-lg text-gray-700 mb-8 max-w-2xl mx-auto">
            Whether you&apos;re buying, selling, or investing, our team is ready to guide you every step of the way.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/properties"
              className="px-8 py-4 bg-accent text-primary font-semibold rounded-md hover:bg-accent/90 transition-all duration-200 shadow-md hover:shadow-lg"
            >
              Browse Properties
            </Link>
            <Link
              href="/contact"
              className="px-8 py-4 bg-primary text-white font-semibold rounded-md hover:bg-primary/90 transition-all duration-200 shadow-md hover:shadow-lg"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
