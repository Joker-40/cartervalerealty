import { Hero } from '@/components/hero';
import { FeaturedProperties } from '@/components/featured-properties';
import { CompanyOverview } from '@/components/company-overview';
import { AgentHighlights } from '@/components/agent-highlights';
import { TestimonialsCarousel } from '@/components/testimonials-carousel';
import { PropertySearch } from '@/components/property-search';

export default function HomePage() {
  return (
    <div>
      <Hero />
      <PropertySearch />
      <FeaturedProperties />
      <CompanyOverview />
      <AgentHighlights />
      <TestimonialsCarousel />
    </div>
  );
}
