'use client';

import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { BRAND } from '@/lib/constants';
import { LeadForm } from '@/components/lead-form';

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-white py-16">
        <div className="mx-auto max-w-content px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">
            Contact <span className="text-accent">Us</span>
          </h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Have questions? We&apos;re here to help you with all your real estate needs
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-content px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-3xl font-serif font-bold text-primary mb-6">Get in Touch</h2>
            <p className="text-gray-700 mb-8 leading-relaxed">
              Whether you&apos;re looking to buy, sell, lease, or invest in real estate, our team of experts is ready to 
              assist you. Reach out to us today and let&apos;s start your real estate journey together.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4 bg-white p-6 rounded-lg shadow-md">
                <MapPin className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-primary mb-1">Office Address</h3>
                  <p className="text-gray-600">{BRAND?.address ?? ''}</p>
                </div>
              </div>

              <div className="flex items-start gap-4 bg-white p-6 rounded-lg shadow-md">
                <Phone className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-primary mb-1">Phone</h3>
                  <a href={`tel:${BRAND?.phone ?? ''}`} className="text-gray-600 hover:text-accent transition-colors">
                    {BRAND?.phone ?? ''}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4 bg-white p-6 rounded-lg shadow-md">
                <Mail className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-primary mb-1">Email</h3>
                  <a href={`mailto:${BRAND?.email ?? ''}`} className="text-gray-600 hover:text-accent transition-colors">
                    {BRAND?.email ?? ''}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4 bg-white p-6 rounded-lg shadow-md">
                <Clock className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-primary mb-1">Office Hours</h3>
                  <div className="text-gray-600 text-sm space-y-1">
                    <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                    <p>Saturday: 10:00 AM - 4:00 PM</p>
                    <p>Sunday: By Appointment</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 bg-white rounded-lg shadow-md overflow-hidden">
              <div className="relative w-full h-80 bg-gray-200">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3445.0877285849756!2d-97.74520908488328!3d30.267153381797886!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8644b5a35e5b3c71%3A0x3da7f1c9e2d0f8f!2sCongress%20Avenue%2C%20Austin%2C%20TX!5e0!3m2!1sen!2sus!4v1234567890123"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Office Location"
                />
              </div>
            </div>
          </div>

          <div>
            <LeadForm />
          </div>
        </div>
      </div>
    </div>
  );
}
