import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { BRAND } from '@/lib/constants';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const data = await request.json();

    const lead = await prisma.lead.create({
      data: {
        name: data?.name ?? '',
        email: data?.email ?? '',
        phone: data?.phone ?? null,
        message: data?.message ?? '',
        propertyId: data?.propertyId ?? null,
        leadCategory: data?.leadCategory ?? 'General Question',
      },
    });

    const htmlBody = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #0F172A; padding: 20px; text-align: center;">
          <h1 style="color: #C9A227; margin: 0; font-size: 24px;">New Lead Inquiry</h1>
        </div>
        
        <div style="background: #F8FAFC; padding: 30px;">
          <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h2 style="color: #0F172A; margin-top: 0; border-bottom: 2px solid #C9A227; padding-bottom: 10px;">
              Contact Information
            </h2>
            <p style="margin: 10px 0;"><strong>Name:</strong> ${data?.name ?? ''}</p>
            <p style="margin: 10px 0;"><strong>Email:</strong> <a href="mailto:${data?.email ?? ''}">${data?.email ?? ''}</a></p>
            ${data?.phone ? `<p style="margin: 10px 0;"><strong>Phone:</strong> <a href="tel:${data.phone}">${data.phone}</a></p>` : ''}
            <p style="margin: 10px 0;"><strong>Inquiry Type:</strong> ${data?.leadCategory ?? ''}</p>
          </div>

          ${data?.propertyTitle ? `
            <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
              <h2 style="color: #0F172A; margin-top: 0; border-bottom: 2px solid #C9A227; padding-bottom: 10px;">
                Property of Interest
              </h2>
              <p style="margin: 10px 0;"><strong>${data.propertyTitle}</strong></p>
            </div>
          ` : ''}

          <div style="background: white; padding: 20px; border-radius: 8px;">
            <h2 style="color: #0F172A; margin-top: 0; border-bottom: 2px solid #C9A227; padding-bottom: 10px;">
              Message
            </h2>
            <div style="background: #F8FAFC; padding: 15px; border-radius: 4px; border-left: 4px solid #C9A227;">
              ${data?.message ?? ''}
            </div>
          </div>
        </div>
        
        <div style="background: #0F172A; padding: 15px; text-align: center;">
          <p style="color: #C9A227; margin: 0; font-size: 12px;">
            Submitted at: ${new Date()?.toLocaleString?.()}
          </p>
        </div>
      </div>
    `;

    const appUrl = process.env.NEXTAUTH_URL ?? '';
    const appName = appUrl ? new URL(appUrl)?.hostname?.split?.('.')?.[0] ?? 'Carter Vale Realty' : 'Carter Vale Realty';

    const emailResponse = await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_LEAD_INQUIRY,
        subject: `New Lead: ${data?.leadCategory ?? 'Inquiry'} from ${data?.name ?? ''}`,
        body: htmlBody,
        is_html: true,
        recipient_email: BRAND?.email ?? 'inquiries@cartervalerealty.com',
        sender_email: `noreply@${appUrl ? new URL(appUrl)?.hostname ?? 'cartervalerealty.com' : 'cartervalerealty.com'}`,
        sender_alias: appName,
      }),
    });

    const emailResult = await emailResponse.json();
    
    if (!emailResult?.success && !emailResult?.notification_disabled) {
      console.error('Email notification failed:', emailResult?.message ?? 'Unknown error');
    }

    return NextResponse.json({ success: true, lead });
  } catch (error: any) {
    console.error('Error creating lead:', error);
    return NextResponse.json(
      { success: false, message: error?.message ?? 'Failed to create lead' },
      { status: 500 }
    );
  }
}
