import { prisma } from '@/lib/prisma';
import { PropertyGallery } from '@/components/property-gallery';
import { PropertyDetails } from '@/components/property-details';
import { AgentContact } from '@/components/agent-contact';
import { LeadForm } from '@/components/lead-form';
import { SimilarProperties } from '@/components/similar-properties';
import { notFound } from 'next/navigation';

export default async function PropertyDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const property = await prisma.property.findUnique({
    where: { id: params?.id ?? '' },
    include: { agent: true },
  });

  if (!property) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-background">
      <PropertyGallery images={property?.galleryImages ?? []} title={property?.title ?? ''} />

      <div className="mx-auto max-w-content px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <PropertyDetails property={property} />
          </div>

          <div className="lg:col-span-1">
            <div className="space-y-6">
              {property?.agent && <AgentContact agent={property.agent} />}
              <LeadForm propertyId={property?.id ?? ''} propertyTitle={property?.title ?? ''} />
            </div>
          </div>
        </div>

        <SimilarProperties
          currentPropertyId={property?.id ?? ''}
          city={property?.city ?? ''}
          propertyType={property?.propertyType ?? ''}
        />
      </div>
    </div>
  );
}
