import { prisma } from '@/lib/prisma';
import { PropertyCard } from '@/components/property-card';
import { PropertyFilters } from '@/components/property-filters';
import { Home } from 'lucide-react';
import type { PropertyFilters as FilterType } from '@/lib/types';

interface SearchParams {
  city?: string;
  minPrice?: string;
  maxPrice?: string;
  bedrooms?: string;
  bathrooms?: string;
  propertyType?: string;
  transactionType?: string;
}

export default async function PropertiesPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const filters: FilterType = {
    city: searchParams?.city ?? undefined,
    minPrice: searchParams?.minPrice ? parseInt(searchParams.minPrice) : undefined,
    maxPrice: searchParams?.maxPrice ? parseInt(searchParams.maxPrice) : undefined,
    bedrooms: searchParams?.bedrooms ? parseInt(searchParams.bedrooms) : undefined,
    bathrooms: searchParams?.bathrooms ? parseInt(searchParams.bathrooms) : undefined,
    propertyType: searchParams?.propertyType ?? undefined,
    transactionType: searchParams?.transactionType ?? undefined,
  };

  const where: any = {};
  if (filters?.city) where.city = filters.city;
  if (filters?.minPrice) where.price = { ...where?.price, gte: filters.minPrice };
  if (filters?.maxPrice) where.price = { ...where?.price, lte: filters.maxPrice };
  if (filters?.bedrooms) where.bedrooms = { gte: filters.bedrooms };
  if (filters?.bathrooms) where.bathrooms = { gte: filters.bathrooms };
  if (filters?.propertyType) where.propertyType = filters.propertyType;
  if (filters?.transactionType) where.transactionType = filters.transactionType;

  const properties = await prisma.property.findMany({
    where,
    include: { agent: true },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-white py-16">
        <div className="mx-auto max-w-content px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">
            Available <span className="text-accent">Properties</span>
          </h1>
          <p className="text-lg text-gray-300">
            Browse our complete collection of properties across Texas
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-content px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <aside className="lg:col-span-1">
            <PropertyFilters currentFilters={filters} />
          </aside>

          <div className="lg:col-span-3">
            <div className="mb-6">
              <p className="text-gray-600">
                Showing <span className="font-semibold text-primary">{properties?.length ?? 0}</span> properties
              </p>
            </div>

            {(properties?.length ?? 0) > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {properties?.map?.((property) => (
                  <PropertyCard key={property?.id ?? ''} property={property} />
                )) ?? []}
              </div>
            ) : (
              <div className="text-center py-20 bg-white rounded-lg shadow-md">
                <Home className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No properties found</h3>
                <p className="text-gray-500">Try adjusting your filters to see more results</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
