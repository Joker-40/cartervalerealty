import { prisma } from '@/lib/prisma';
import { AgentProfileCard } from '@/components/agent-profile-card';
import { Users } from 'lucide-react';

export default async function AgentsPage() {
  const agents = await prisma.agent.findMany({
    orderBy: { yearsExperience: 'desc' },
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-white py-16">
        <div className="mx-auto max-w-content px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">
            Our Expert <span className="text-accent">Agents</span>
          </h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Meet our dedicated team of real estate professionals committed to helping you find your perfect property
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-content px-4 sm:px-6 lg:px-8 py-12">
        {(agents?.length ?? 0) > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {agents?.map?.((agent) => (
              <AgentProfileCard key={agent?.id ?? ''} agent={agent} />
            )) ?? []}
          </div>
        ) : (
          <div className="text-center py-20">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No agents available</h3>
          </div>
        )}
      </div>
    </div>
  );
}
