export const BRAND = {
  name: 'Carter & Vale Realty Group',
  tagline: 'Where Smart Investments Meet Real Homes',
  founded: 2012,
  email: 'inquiries@cartervalerealty.com',
  phone: '(512) 555-0123',
  address: '123 Congress Avenue, Suite 500, Austin, TX 78701',
};

export const COLORS = {
  primary: '#0F172A',
  accent: '#C9A227',
  background: '#F8FAFC',
  secondaryBg: '#F1F5F9',
  text: '#111827',
};

export const CITIES = ['Austin', 'Dallas', 'Houston'];

export const PROPERTY_TYPES = ['Residential', 'Commercial', 'Office', 'Retail'];

export const TRANSACTION_TYPES = ['Buy', 'Rent', 'Lease'];

export const LEAD_CATEGORIES = [
  'Buyer Inquiry',
  'Seller Inquiry',
  'Commercial Lease Inquiry',
  'Schedule Property Visit',
  'General Question',
];

export const AMENITIES = [
  'Parking',
  'Pool',
  'Gym',
  'Security',
  'Elevator',
  'Air Conditioning',
  'Heating',
  'Balcony',
  'Garden',
  'Furnished',
  'Pet Friendly',
  'Wheelchair Accessible',
];
