export interface Property {
  id: string;
  title: string;
  price: number;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  bedrooms?: number | null;
  bathrooms?: number | null;
  squareFootage: number;
  propertyType: string;
  transactionType: string;
  amenities: string[];
  description: string;
  galleryImages: string[];
  assignedAgentId?: string | null;
  featured: boolean;
  createdAt: Date;
  updatedAt: Date;
  agent?: Agent | null;
}

export interface Agent {
  id: string;
  name: string;
  title: string;
  email: string;
  phone: string;
  photoUrl: string;
  bio: string;
  yearsExperience: number;
  specialization: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  message: string;
  propertyId?: string | null;
  leadCategory: string;
  createdAt: Date;
}

export interface Testimonial {
  id: string;
  clientName: string;
  clientTitle: string;
  testimonialText: string;
  rating: number;
  createdAt: Date;
}

export interface PropertyFilters {
  city?: string;
  minPrice?: number;
  maxPrice?: number;
  bedrooms?: number;
  bathrooms?: number;
  propertyType?: string;
  transactionType?: string;
}
